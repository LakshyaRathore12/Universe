import fs from 'fs';
import path from 'path';
import archiver from 'archiver';

const rootDir = process.cwd();
const publicDir = path.join(rootDir, 'public');

if (!fs.existsSync(publicDir)) {
  fs.mkdirSync(publicDir, { recursive: true });
}

function createZip(outputPath: string, populate: (archive: archiver.Archiver) => void): Promise<void> {
  return new Promise((resolve, reject) => {
    const output = fs.createWriteStream(outputPath);
    const archive = archiver('zip', { zlib: { level: 9 } });

    output.on('close', () => {
      console.log(`[ZIP] Created ${path.basename(outputPath)} (${(archive.pointer() / 1024).toFixed(1)} KB)`);
      resolve();
    });

    archive.on('error', (err) => reject(err));
    archive.pipe(output);
    populate(archive);
    archive.finalize();
  });
}

async function buildAllArchives() {
  console.log('Generating separate ZIP packages...');

  // 1. Database Archive
  await createZip(path.join(publicDir, 'database.zip'), (archive) => {
    archive.directory(path.join(rootDir, 'database'), 'database');
  });

  // 2. Backend Archive
  await createZip(path.join(publicDir, 'backend.zip'), (archive) => {
    archive.directory(path.join(rootDir, 'backend'), 'backend');
    archive.directory(path.join(rootDir, 'database'), 'database');
  });

  // 3. Frontend Archive
  await createZip(path.join(publicDir, 'frontend.zip'), (archive) => {
    archive.directory(path.join(rootDir, 'src'), 'src');
    archive.directory(path.join(rootDir, 'frontend'), 'frontend');
    archive.file(path.join(rootDir, 'index.html'), { name: 'index.html' });
    archive.file(path.join(rootDir, 'vite.config.ts'), { name: 'vite.config.ts' });
    archive.file(path.join(rootDir, 'tsconfig.json'), { name: 'tsconfig.json' });
  });

  // 4. Complete Project Archive
  await createZip(path.join(publicDir, 'universe-event-management.zip'), (archive) => {
    archive.glob('**/*', {
      cwd: rootDir,
      ignore: [
        'node_modules/**',
        'dist/**',
        '.git/**',
        '.aistudio/**',
        'public/*.zip',
        '.cache/**'
      ]
    });
  });

  console.log('All archives generated successfully!');
}

buildAllArchives().catch(console.error);
